Jabar & Banten Cultural Journey Pack
====================================

This digital pack includes:
- Hidden gems location map (.kml)
- Culinary recipes PDF
- Folk story audio
- Ritual & documentary videos
- Cultural coupons

Explore West Java & Banten culture, anytime, anywhere!
